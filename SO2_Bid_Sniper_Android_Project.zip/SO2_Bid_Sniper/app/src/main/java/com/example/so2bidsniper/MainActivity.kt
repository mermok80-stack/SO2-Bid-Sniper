package com.example.so2bidsniper

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.content.Context
import android.content.SharedPreferences
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale
import kotlin.math.max

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var list: LinearLayout
    private lateinit var nameInput: EditText
    private lateinit var currentInput: EditText
    private lateinit var stepInput: EditText
    private lateinit var maxInput: EditText
    private lateinit var status: TextView
    private val fmt = DecimalFormat("0.00", DecimalFormatSymbols(Locale.US))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("so2_bids", Context.MODE_PRIVATE)
        buildUi()
        renderItems()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(0xFFF4F6F8.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        val title = TextView(this).apply {
            text = "SO2 Bid Sniper"
            textSize = 26f
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xFF17202A.toInt())
        }
        content.addView(title)
        content.addView(TextView(this).apply {
            text = "Мониторинг и расчёт цены запроса"
            textSize = 14f
            setTextColor(0xFF52616B.toInt())
            setPadding(0, dp(4), 0, dp(14))
        })

        val notice = TextView(this).apply {
            text = "Демо-версия: цены вводятся вручную. Приложение пока не подключено к рынку Standoff 2 и не отправляет запросы."
            textSize = 13f
            setTextColor(0xFF7A4E00.toInt())
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(0xFFFFE8B3.toInt())
        }
        content.addView(notice)

        content.addView(label("Добавить скин"))
        nameInput = input("Название скина")
        content.addView(nameInput)
        currentInput = input("Текущий максимальный запрос, например 11.30")
        content.addView(currentInput)
        stepInput = input("Шаг перебивания (G)", "0.01")
        content.addView(stepInput)
        maxInput = input("Максимальная цена (G), например 15.00")
        content.addView(maxInput)

        val add = Button(this).apply {
            text = "Рассчитать и сохранить"
            setOnClickListener { addItem() }
        }
        content.addView(add)

        status = TextView(this).apply {
            textSize = 13f
            setTextColor(0xFF34495E.toInt())
            setPadding(0, dp(8), 0, dp(8))
        }
        content.addView(status)
        content.addView(label("Список отслеживания"))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list)

        val footer = TextView(this).apply {
            text = "Подсказка: целевая цена = текущий запрос + шаг. Если она выше установленного лимита, покупку стоит пропустить."
            textSize = 12f
            setTextColor(0xFF52616B.toInt())
            setPadding(0, dp(14), 0, dp(10))
        }
        content.addView(footer)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun label(s: String) = TextView(this).apply {
        text = s
        textSize = 17f
        setTypeface(null, Typeface.BOLD)
        setTextColor(0xFF17202A.toInt())
        setPadding(0, dp(16), 0, dp(6))
    }

    private fun input(hintText: String, default: String = "") = EditText(this).apply {
        hint = hintText
        setText(default)
        textSize = 15f
        singleLine = true
        inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        setPadding(dp(12), dp(8), dp(12), dp(8))
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(0xFFFFFFFF.toInt())
            cornerRadius = dp(10).toFloat()
            setStroke(dp(1), 0xFFD8DEE5.toInt())
        }
        val lp = LinearLayout.LayoutParams(-1, dp(52))
        lp.bottomMargin = dp(8)
        layoutParams = lp
    }

    private fun parseNum(s: String): Double? =
        s.trim().replace(',', '.').toDoubleOrNull()

    private fun addItem() {
        val name = nameInput.text.toString().trim()
        val current = parseNum(currentInput.text.toString())
        val step = parseNum(stepInput.text.toString())
        val maxPrice = parseNum(maxInput.text.toString())

        if (name.isEmpty() || current == null || step == null || maxPrice == null ||
            current < 0 || step <= 0 || maxPrice < 0) {
            status.text = "Проверь поля: укажи название и корректные цены."
            return
        }
        val target = current + step
        if (target > maxPrice) {
            status.text = "Целевая цена ${fmt.format(target)} G выше лимита ${fmt.format(maxPrice)} G. Запись не добавлена."
            return
        }
        val id = System.currentTimeMillis().toString()
        val item = listOf(name, fmt.format(current), fmt.format(step), fmt.format(maxPrice), fmt.format(target)).joinToString("|")
        prefs.edit().putString(id, item).apply()
        status.text = "Расчёт: ${fmt.format(current)} + ${fmt.format(step)} = ${fmt.format(target)} G"
        nameInput.text.clear()
        currentInput.text.clear()
        maxInput.text.clear()
        renderItems()
    }

    private fun renderItems() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val all = prefs.all.entries.sortedByDescending { it.key }.filter { it.value is String }
        if (all.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "Пока нет скинов. Добавь первый выше."
                textSize = 14f
                setTextColor(0xFF52616B.toInt())
                setPadding(0, dp(8), 0, dp(8))
            })
            return
        }
        for ((key, raw) in all) {
            val parts = (raw as String).split("|")
            if (parts.size != 5) continue
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(0xFFFFFFFF.toInt())
                    cornerRadius = dp(12).toFloat()
                    setStroke(dp(1), 0xFFE0E5EA.toInt())
                }
            }
            card.addView(TextView(this).apply {
                text = parts[0]
                textSize = 17f
                setTypeface(null, Typeface.BOLD)
                setTextColor(0xFF17202A.toInt())
            })
            card.addView(TextView(this).apply {
                text = "Макс. запрос: ${parts[1]} G  •  Шаг: ${parts[2]} G\nЦелевая цена: ${parts[4]} G  •  Лимит: ${parts[3]} G"
                textSize = 14f
                setTextColor(0xFF34495E.toInt())
                setPadding(0, dp(5), 0, dp(5))
            })
            val remove = Button(this).apply {
                text = "Удалить"
                setOnClickListener {
                    prefs.edit().remove(key).apply()
                    renderItems()
                }
            }
            card.addView(remove)
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = dp(10)
            list.addView(card, lp)
        }
    }
}
